---
name: General inquiry
about: Free form communication.
title: "[Inquiry]"
labels: question
assignees: ''

---

We do encourage you to take a look at [FreeRTOS official site](https://www.freertos.org) for general information and [FreeRTOS forum](https://forums.freertos.org) to access our community.

If still needed, could create a general inquiry report here.
