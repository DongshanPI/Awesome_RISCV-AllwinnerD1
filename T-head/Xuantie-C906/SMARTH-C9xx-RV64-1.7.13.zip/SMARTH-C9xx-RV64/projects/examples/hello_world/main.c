/*
 * Copyright (C) 2017-2019 Alibaba Group Holding Limited
 */


/******************************************************************************
 * @file     main.c
 * @brief    hello world
 * @version  V1.0
 * @date     17. Jan 2018
 ******************************************************************************/

#include <stdio.h>

int main(void)
{
    printf("Hello World!\n");

    printf("helloworld runs successfully!\n");
    return 0;
}
