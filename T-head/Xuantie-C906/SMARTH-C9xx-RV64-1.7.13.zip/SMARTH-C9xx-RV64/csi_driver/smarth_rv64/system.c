/*
 * Copyright (C) 2017-2019 Alibaba Group Holding Limited
 */


/******************************************************************************
 * @file     system.c
 * @brief    CSI Device System Source File
 * @version  V1.0
 * @date     02. Oct 2018
 ******************************************************************************/

#include <csi_config.h>
#include <soc.h>
#include <csi_core.h>
#include <drv_irq.h>

#ifndef CONFIG_SYSTICK_HZ
#define CONFIG_SYSTICK_HZ 100
#endif

#define PRV_U                           0
#define PRV_S                           1
#define PRV_M                           3


#define MSTATUS_SIE                     0x00000002
#define MSTATUS_MIE                     0x00000008
#define MSTATUS_SPIE_SHIFT              5
#define MSTATUS_SPIE                    (1 << MSTATUS_SPIE_SHIFT)
#define MSTATUS_UBE                     0x00000040
#define MSTATUS_MPIE                    0x00000080
#define MSTATUS_SPP_SHIFT               8
#define MSTATUS_SPP                     (1 << MSTATUS_SPP_SHIFT)
#define MSTATUS_MPP_SHIFT               11
#define MSTATUS_MPP                     (3 << MSTATUS_MPP_SHIFT)

#define INSERT_FIELD(val, which, fieldval)	(((val) & ~(which)) | ((fieldval) * ((which) & ~((which)-1))))

int g_system_clock = IHS_VALUE;
extern uint64_t __Vectors;
extern int32_t g_top_irqstack;
extern void irq_vectors_init(void);
extern void mm_heap_initialize(void);

int32_t drv_get_cpu_id(void)
{
    return 0;
}

#ifdef CONFIG_KERNEL_NONE
void _system_init_for_baremetal(void)
{
    /* enable external interrupt & soft interrupt */
#ifdef __SMODE_SUPPORT
    uint32_t sie = __get_SIE();
    sie |= (1 << 9 | 1 << 1);
    __set_SIE(sie);
#else
    uint32_t mie = __get_MIE();
    mie |= (1 << 11 | 1 << 3);
    __set_MIE(mie);
#endif
    /* enable global interrupt */
    __enable_excp_irq();

    csi_coret_config(drv_get_coret_freq() / CONFIG_SYSTICK_HZ, 0);    //10ms

    mm_heap_initialize();
}
#endif

#ifndef CONFIG_KERNEL_NONE
void _system_init_for_kernel(void)
{
    irq_vectors_init();
    
#ifdef __SMODE_SUPPORT
    /* enable coreTim interrupt */
    uint32_t sie = __get_SIE();
    sie |= (1 << 9 | 1 << 5 | 1 << 1);
    __set_SIE(sie);
#else
    uint32_t mie = __get_MIE();
    mie |= (1 << 11 | 1 << 7 | 1 << 3);
    __set_MIE(mie);
#endif
    csi_coret_config(drv_get_coret_freq() / CONFIG_SYSTICK_HZ, 0);    //10ms
#ifndef CONFIG_KERNEL_RHINO
#ifndef CONFIG_NUTTXMM_NONE
    mm_heap_initialize();
#endif
#endif
}
#endif




/*
 *  * Miscellaneous MMU related constants
 *   */

#define ATTR_SO                 (1ull << 4)
#define ATTR_CA                 (1ull << 3)
#define ATTR_BU                 (1ull << 2)
#define ATTR_SH                 (1ull << 1)
#define ATTR_SE                 (1ull << 0)

#define UPPER_ATTRS_SHIFT       (59)
#define UPPER_ATTRS(x)          (((x) & 0x1f) << UPPER_ATTRS_SHIFT)

#define DIRTY_FLAG              (1ull << 6)
#define ACCESS_FLAG             (1ull << 5)
#define GLOBAL_FLAG             (1ull << 4)
#define AP_UNPRIV               (1ull << 3)
#define AP_X                    (1ull << 2)
#define AP_W                    (1ull << 1)
#define AP_R                    (1ull << 0)

#define LOWER_ATTRS_SHIFT               1
#define LOWER_ATTRS(x)                  (((x) & 0x1ff) << LOWER_ATTRS_SHIFT)


uint64_t page_table[512] __attribute__ ((aligned(4096)));

void _mmu_init(void) __attribute__((noinline));

void _mmu_init(void)
{
    /* setup mmu VA(0 ~ 512G-1) <==>  PA(0 ~ 512G-1) */
    for (uint64_t i = 0; i < 512; i++)
    {
        page_table[i] = (UPPER_ATTRS(ATTR_CA | ATTR_BU | ATTR_SH) | i << 28 | LOWER_ATTRS(DIRTY_FLAG | ACCESS_FLAG | AP_X | AP_W | AP_R | GLOBAL_FLAG)) | 0x1;
    }

    /* setup mmu VA(0G ~ 3G-1) <==>  PA(0G ~ 3G-1) */
    page_table[0] = (UPPER_ATTRS(ATTR_SO | ATTR_SH) | 0x0 << 28 | LOWER_ATTRS(DIRTY_FLAG | ACCESS_FLAG | AP_X | AP_W | AP_R | GLOBAL_FLAG)) | 0x1;
    page_table[1] = (UPPER_ATTRS(ATTR_SO | ATTR_SH) | 0x1 << 28 | LOWER_ATTRS(DIRTY_FLAG | ACCESS_FLAG | AP_X | AP_W | AP_R | GLOBAL_FLAG)) | 0x1;
    page_table[2] = (UPPER_ATTRS(ATTR_SO | ATTR_SH) | 0x2 << 28 | LOWER_ATTRS(DIRTY_FLAG | ACCESS_FLAG | AP_X | AP_W | AP_R | GLOBAL_FLAG)) | 0x1;

    __set_SATP(((uint64_t)&page_table >> 12));
    csi_mmu_enable(MMU_MODE_39);
}

void _system_switchto_smode(void)
{
    unsigned long val;
    val = __get_MSTATUS();
    val = INSERT_FIELD(val, MSTATUS_MPP, PRV_S);
    val = INSERT_FIELD(val, MSTATUS_MPIE, 1);
    __set_MSTATUS(val);
    
    /* setup S-Mode csr regs */
    __set_STVEC((uint64_t)(&__Vectors) | (uint64_t)0x1);

    /* setup SATP */
    __set_SATP(0x0);

    __ASM("auipc a0, 0");
    __ASM("addi  a0, a0, 14");
    __ASM("csrw  mepc, a0");
    __ASM("mret");
}

void _system_init_for_smode(void)
{
    _system_switchto_smode();
}

void _system_init_for_plic(void)
{
    int i;

    for (i = 0; i < 1023; i++) {
    	PLIC->PLIC_PRIO[i] = 31;
    }

    for (i = 0; i < 32; i++) {
    	PLIC->PLIC_IP[i] = 0;
    }

    for (i = 0; i < 32; i++) {
    	PLIC->PLIC_H0_MIE[i] = 0;
    	PLIC->PLIC_H0_SIE[i] = 0;
    }

    /* set hart threshold 0, enable all interrupt */
    PLIC->PLIC_H0_MTH = 0;
    PLIC->PLIC_H0_STH = 0;

    for (i = 0; i < 1023; i++) {
    	PLIC->PLIC_H0_MCLAIM = i;
    	PLIC->PLIC_H0_SCLAIM = i;
    }

    /* set PLIC_PER */
    PLIC->PLIC_PER = 0x1;
}


void smode_init(void)
{
#ifdef __SMODE_SUPPORT
    _system_init_for_smode();
    _mmu_init();    
#endif
}

/**
  * @brief  initialize the system
  *         Initialize the psr and vbr.
  * @param  None
  * @return None
  */
void SystemInit(void)
{
    /* enable ecall delegate */
    uint64_t medeleg = __get_MEDELEG();
    medeleg |= (1 << 9);
    __set_MEDELEG(medeleg);

    /* enable interrupt delegate */
    uint64_t mideleg = __get_MIDELEG();
    mideleg |= 0x222;
    __set_MIDELEG(mideleg);

    /* enable theadisaee  */
    uint64_t mxstatus = __get_MXSTATUS();
    mxstatus |= (1 << 22);
    __set_MXSTATUS(mxstatus);

#ifdef __SMODE_SUPPORT
    /* enable mcounteren for s-mode */
    __set_MCOUNTEREN(0xffffffff);
#endif

    g_system_clock = IHS_VALUE;

    _system_init_for_plic();

    /* enable cache */
    csi_dcache_enable();
    csi_icache_enable();

#ifdef CONFIG_KERNEL_NONE
    _system_init_for_baremetal();
#else
    _system_init_for_kernel();
#endif
}
